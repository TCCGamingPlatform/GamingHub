import firebase from "firebase";

const firebaseConfig = {
    apiKey: "AIzaSyAymzk4gkNP9SUGp-1PENrbSjnhXrk9J9U",
    authDomain: "gaminghubsite-e6bc4.firebaseapp.com",
    databaseURL: "https://gaminghubsite-e6bc4.firebaseio.com",
    projectId: "gaminghubsite-e6bc4",
    storageBucket: "gaminghubsite-e6bc4.appspot.com",
    messagingSenderId: "353819448583",
    appId: "1:353819448583:web:f73f231106bb25d73fe1a2"
  };

  const firebaseApp = firebase.initializeApp(firebaseConfig);
  const db = firebaseApp.firestore();
  const auth = firebase.auth();
  const provider = new firebase.auth.GoogleAuthProvider();

  export {auth, provider}; 
  export default db;