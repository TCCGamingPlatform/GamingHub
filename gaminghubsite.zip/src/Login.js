import { Button } from '@material-ui/core';
import React from 'react';
import  { auth, provider } from './firebase';
import "./Login.css";




function Login() {


    
    const signIn = () => {
        // google login
        
        
        auth.signInWithPopup(provider)
        .catch(error => alert(error.message)); 

    }

    return (
        <div className = "login">
            <div className="login__logo">
                <img src="https://cdn.discordapp.com/attachments/672992667055030292/782718546316099644/logo2.png" alt=""/>
            </div>

            

            <Button onClick={signIn} > Entrar </Button>
        </div>
    )
}

export default Login
